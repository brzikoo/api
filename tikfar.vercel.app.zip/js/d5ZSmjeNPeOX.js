// DOM Elements
const urlInput = document.getElementById('urlInput');
const downloadBtn = document.getElementById('downloadBtn');
const spinner = document.getElementById('spinner');
const errorMessage = document.getElementById('errorMessage');
const successMessage = document.getElementById('successMessage');
const result = document.getElementById('result');
const videoThumbnail = document.getElementById('videoThumbnail');
const videoTitle = document.getElementById('videoTitle');
const authorAvatar = document.getElementById('authorAvatar');
const authorName = document.getElementById('authorName');
const authorUsername = document.getElementById('authorUsername');
const playCount = document.getElementById('playCount');
const diggCount = document.getElementById('diggCount');
const commentCount = document.getElementById('commentCount');
const shareCount = document.getElementById('shareCount');
const createTime = document.getElementById('createTime');
const region = document.getElementById('region');
const duration = document.getElementById('duration');
const hdDownloadLink = document.getElementById('hdDownloadLink');
const wmDownloadLink = document.getElementById('wmDownloadLink');
const nowmDownloadLink = document.getElementById('nowmDownloadLink');
const musicDownloadLink = document.getElementById('musicDownloadLink');
const themeToggle = document.getElementById('themeToggle');
const hamburger = document.getElementById('hamburger');
const navMenu = document.getElementById('navMenu');
const aboutBtn = document.getElementById('aboutBtn');
const aboutLink = document.getElementById('aboutLink');
const aboutModal = document.getElementById('aboutModal');
const aboutModalClose = document.getElementById('aboutModalClose');
const thanksLink = document.getElementById('thanksLink');
const thanksModal = document.getElementById('thanksModal');
const thanksModalClose = document.getElementById('thanksModalClose');
const accordionItems = document.querySelectorAll('.accordion-item');
const testimonialTrack = document.getElementById('testimonialTrack');
const testimonialPrev = document.getElementById('testimonialPrev');
const testimonialNext = document.getElementById('testimonialNext');
const testimonialDots = document.getElementById('testimonialDots');
const stars = document.querySelectorAll('.star');
const commentForm = document.getElementById('commentForm');
const commentInput = document.getElementById('commentInput');
const thumbnailContainer = document.getElementById('thumbnailContainer');
const playOverlay = document.getElementById('playOverlay');
const imageSlider = document.getElementById('imageSlider');
const sliderImages = document.getElementById('sliderImages');
const imagePrev = document.getElementById('imagePrev');
const imageNext = document.getElementById('imageNext');
const imageDots = document.getElementById('imageDots');
const downloadOptions = document.getElementById('downloadOptions');
const imageDownloadOptions = document.getElementById('imageDownloadOptions');
const downloadAllImages = document.getElementById('downloadAllImages');
const individualImageButtons = document.getElementById('individualImageButtons');
const donateBtn = document.getElementById('donateBtn');
const contactBtn = document.getElementById('contactBtn');
const donateLink = document.getElementById('donateLink');
const contactLink = document.getElementById('contactLink');
const donateModal = document.getElementById('donateModal');
const donateModalClose = document.getElementById('donateModalClose');
const contactModal = document.getElementById('contactModal');
const contactModalClose = document.getElementById('contactModalClose');
const contactForm = document.getElementById('contactForm');

// State variables
let currentTestimonial = 0;
let userRating = 0;
let testimonials = [];
let userReviews = JSON.parse(localStorage.getItem('userReviews')) || [];
let currentImageIndex = 0;
let imageSlides = [];

// API Base URL
const API_BASE_URL = '/api';

// Initialize the application
function init() {
    // Set up event listeners
    setupEventListeners();
    
    // Initialize testimonials
    initTestimonials();
    
    // Initialize rating stars
    initRatingStars();
    
    // Load user reviews
    loadUserReviews();
    
    // Check for saved theme preference
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        document.documentElement.setAttribute('data-theme', savedTheme);
        themeToggle.innerHTML = savedTheme === 'dark' 
            ? '<i class="fas fa-sun"></i>' 
            : '<i class="fas fa-moon"></i>';
    }
    
    // Initialize scroll animations
    initScrollAnimations();
    
    // Initialize marquee
    initMarquee();
}

// Set up all event listeners
function setupEventListeners() {
    // Download button click
    downloadBtn.addEventListener('click', handleDownload);
    
    // Theme toggle
    themeToggle.addEventListener('click', toggleTheme);
    
    // Mobile menu toggle
    hamburger.addEventListener('click', toggleMobileMenu);
    
    // Modal controls
    aboutBtn.addEventListener('click', () => openModal(aboutModal));
    aboutLink.addEventListener('click', (e) => {
        e.preventDefault();
        openModal(aboutModal);
    });
    aboutModalClose.addEventListener('click', () => closeModal(aboutModal));
    
    thanksLink.addEventListener('click', (e) => {
        e.preventDefault();
        openModal(thanksModal);
    });
    thanksModalClose.addEventListener('click', () => closeModal(thanksModal));
    
    // New modal controls
    donateBtn.addEventListener('click', () => openModal(donateModal));
    contactBtn.addEventListener('click', () => openModal(contactModal));
    donateLink.addEventListener('click', (e) => {
        e.preventDefault();
        openModal(donateModal);
    });
    contactLink.addEventListener('click', (e) => {
        e.preventDefault();
        openModal(contactModal);
    });
    donateModalClose.addEventListener('click', () => closeModal(donateModal));
    contactModalClose.addEventListener('click', () => closeModal(contactModal));
    
    // FAQ accordion
    accordionItems.forEach(item => {
        const header = item.querySelector('.accordion-header');
        header.addEventListener('click', () => toggleAccordion(item));
    });
    
    // Testimonial slider controls
    testimonialPrev.addEventListener('click', () => navigateTestimonials(-1));
    testimonialNext.addEventListener('click', () => navigateTestimonials(1));
    
    // Rating stars
    stars.forEach(star => {
        star.addEventListener('click', handleStarClick);
        star.addEventListener('mouseover', handleStarHover);
    });
    
    // Comment form submission
    commentForm.addEventListener('submit', handleCommentSubmit);
    
    // Image slider controls
    imagePrev.addEventListener('click', () => navigateImages(-1));
    imageNext.addEventListener('click', () => navigateImages(1));
    
    // Download all images
    downloadAllImages.addEventListener('click', handleDownloadAllImages);
    
    // Contact form submission
    contactForm.addEventListener('submit', handleContactSubmit);
    
    // Close modals when clicking outside
    window.addEventListener('click', (e) => {
        if (e.target === aboutModal) closeModal(aboutModal);
        if (e.target === thanksModal) closeModal(thanksModal);
        if (e.target === donateModal) closeModal(donateModal);
        if (e.target === contactModal) closeModal(contactModal);
    });
    
    // Close mobile menu when clicking outside
    document.addEventListener('click', (e) => {
        if (!hamburger.contains(e.target) && !navMenu.contains(e.target) && navMenu.classList.contains('active')) {
            toggleMobileMenu();
        }
    });
}

// Initialize scroll animations
function initScrollAnimations() {
    const observerOptions = {
        root: null,
        rootMargin: '0px',
        threshold: 0.1
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    }, observerOptions);

    // Observe all sections and cards
    document.querySelectorAll('section, .card, .step-card, .feature-card').forEach(el => {
        el.classList.add('fade-in');
        observer.observe(el);
    });
}

// Initialize marquee
function initMarquee() {
    const marqueeContent = document.querySelector('.marquee-content');
    // Duplicate content for seamless loop
    marqueeContent.innerHTML += marqueeContent.innerHTML;
}

// Handle download process
async function handleDownload() {
    const url = urlInput.value.trim();
    
    // Validate URL
    if (!url) {
        showError('Please enter a TikTok URL');
        return;
    }
    
    if (!isValidTikTokUrl(url)) {
        showError('Please enter a valid TikTok URL');
        return;
    }
    
    // Start download process
    await startDownload(url);
}

// Validate TikTok URL
function isValidTikTokUrl(url) {
    const tiktokRegex = /https?:\/\/(www\.|vm\.|vt\.|m\.)?tiktok\.com\/.+/;
    return tiktokRegex.test(url);
}

// Start download process
async function startDownload(url) {
    // Show loading state
    showLoading();
    hideError();
    hideSuccess();
    
    try {
        // Call API
        const response = await fetch(`${API_BASE_URL}/download`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ url })
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || 'Failed to fetch video data');
        }
        
        const data = await response.json();
        
        // Hide loading
        hideLoading();
        
        // Display video data
        displayVideoData(data);
        
        // Show success message
        showSuccess('Video information retrieved successfully!');
        
    } catch (error) {
        console.error('Error:', error.message);
        hideLoading();
        showError(error.message || 'Failed to download video. Please make sure the URL is correct and try again.');
    }
}

// Display video data in the UI
function displayVideoData(data) {
    // Set video information
    videoThumbnail.src = data.cover;
    videoTitle.textContent = data.title;
    authorAvatar.src = data.author.avatar;
    authorName.textContent = data.author.nickname;
    authorUsername.textContent = `@${data.author.unique_id}`;
    
    // Set video stats
    playCount.textContent = formatNumber(data.play_count);
    diggCount.textContent = formatNumber(data.digg_count);
    commentCount.textContent = formatNumber(data.comment_count);
    shareCount.textContent = formatNumber(data.share_count);
    
    // Set video meta
    createTime.textContent = formatTimestamp(data.create_time);
    region.textContent = `Region: ${data.region}`;
    duration.textContent = `Duration: ${formatDuration(data.duration)}`;
    
    // Check if it's a video or image slides
    if (data.images && data.images.length > 0) {
        // It's an image slides post
        displayImageSlides(data);
    } else {
        // It's a video post
        displayVideoContent(data);
    }
    
    // Show result section
    result.style.display = 'block';
    
    // Smooth scroll to result
    setTimeout(() => {
        result.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 300);
}

// Display video content
function displayVideoContent(data) {
    // Hide image slider and show video thumbnail
    imageSlider.style.display = 'none';
    videoThumbnail.style.display = 'block';
    playOverlay.style.display = 'flex';
    
    // Set download links for video
    hdDownloadLink.href = data.hdplay || data.play;
    wmDownloadLink.href = data.wmplay || data.play;
    nowmDownloadLink.href = data.play;
    musicDownloadLink.href = data.music_info.play;
    
    // Add download attributes
    const videoTitleSlug = data.title.replace(/[^a-zA-Z0-9]/g, '-').toLowerCase();
    hdDownloadLink.setAttribute('download', `${videoTitleSlug}-hd.mp4`);
    wmDownloadLink.setAttribute('download', `${videoTitleSlug}-wm.mp4`);
    nowmDownloadLink.setAttribute('download', `${videoTitleSlug}.mp4`);
    musicDownloadLink.setAttribute('download', `${videoTitleSlug}-music.mp3`);
    
    // Show video download options, hide image options
    downloadOptions.style.display = 'grid';
    imageDownloadOptions.style.display = 'none';
}

// Display image slides with individual download buttons
function displayImageSlides(data) {
    // Hide video elements and show image slider
    videoThumbnail.style.display = 'none';
    playOverlay.style.display = 'none';
    imageSlider.style.display = 'flex';
    
    // Store images for navigation
    imageSlides = data.images;
    
    // Clear previous images and dots
    sliderImages.innerHTML = '';
    imageDots.innerHTML = '';
    
    // Create image elements and dots
    imageSlides.forEach((imageUrl, index) => {
        // Create image element
        const img = document.createElement('img');
        img.src = imageUrl;
        img.alt = `Slide ${index + 1}`;
        img.classList.add('slider-image');
        if (index !== 0) img.style.display = 'none';
        sliderImages.appendChild(img);
        
        // Create dot element
        const dot = document.createElement('div');
        dot.classList.add('slider-dot');
        if (index === 0) dot.classList.add('active');
        dot.addEventListener('click', () => navigateToImage(index));
        imageDots.appendChild(dot);
    });
    
    // Create individual download buttons for each image
    individualImageButtons.innerHTML = '';
    imageSlides.forEach((imageUrl, index) => {
        const button = document.createElement('a');
        button.href = imageUrl;
        button.setAttribute('download', `tiktok-image-${index + 1}.jpg`);
        button.classList.add('download-image-btn', 'glow-effect');
        button.innerHTML = `<i class="fas fa-download"></i> Download Image ${index + 1}`;
        individualImageButtons.appendChild(button);
    });
    
    // Set up download for all images
    downloadAllImages.href = imageSlides[0];
    downloadAllImages.setAttribute('download', 'tiktok-images.zip');
    
    // Show image download options, hide video options
    downloadOptions.style.display = 'none';
    imageDownloadOptions.style.display = 'grid';
}

// Navigate through images
function navigateImages(direction) {
    const newIndex = (currentImageIndex + direction + imageSlides.length) % imageSlides.length;
    navigateToImage(newIndex);
}

// Navigate to specific image
function navigateToImage(index) {
    // Hide current image
    document.querySelectorAll('.slider-image')[currentImageIndex].style.display = 'none';
    document.querySelectorAll('.slider-dot')[currentImageIndex].classList.remove('active');
    
    // Show new image
    document.querySelectorAll('.slider-image')[index].style.display = 'block';
    document.querySelectorAll('.slider-dot')[index].classList.add('active');
    
    // Update current index
    currentImageIndex = index;
}

// Handle download all images
function handleDownloadAllImages(e) {
    e.preventDefault();
    
    if (imageSlides.length === 0) return;
    
    // For single image, download directly
    if (imageSlides.length === 1) {
        const link = document.createElement('a');
        link.href = imageSlides[0];
        link.download = 'tiktok-image.jpg';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        return;
    }
    
    // For multiple images, we would need a server-side solution to zip them
    // For now, we'll download them one by one
    alert('For multiple images, please download each image individually. Server-side zip functionality would be required for bulk download.');
}

// Format number with commas
function formatNumber(num) {
    return new Intl.NumberFormat().format(num);
}

// Format timestamp to readable date
function formatTimestamp(timestamp) {
    const date = new Date(timestamp * 1000);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

// Format duration in seconds to minutes:seconds
function formatDuration(seconds) {
    if (seconds === 0) return 'Image Slides';
    
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
}

// Toggle theme between light and dark
function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    
    // Update icon
    themeToggle.innerHTML = newTheme === 'dark' 
        ? '<i class="fas fa-sun"></i>' 
        : '<i class="fas fa-moon"></i>';
}

// Toggle mobile menu
function toggleMobileMenu() {
    navMenu.classList.toggle('active');
    hamburger.classList.toggle('active');
}

// Open modal
function openModal(modal) {
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
}

// Close modal
function closeModal(modal) {
    modal.classList.remove('active');
    document.body.style.overflow = 'auto';
}

// Toggle FAQ accordion item
function toggleAccordion(item) {
    // Close all other items
    accordionItems.forEach(otherItem => {
        if (otherItem !== item && otherItem.classList.contains('active')) {
            otherItem.classList.remove('active');
        }
    });
    
    // Toggle current item
    item.classList.toggle('active');
}

// Initialize testimonials
function initTestimonials() {
    testimonials = document.querySelectorAll('.testimonial-slide');
    
    // Create dots for testimonial navigation
    testimonials.forEach((_, i) => {
        const dot = document.createElement('div');
        dot.classList.add('slider-dot');
        if (i === 0) dot.classList.add('active');
        dot.addEventListener('click', () => navigateToTestimonial(i));
        testimonialDots.appendChild(dot);
    });
    
    // Auto-rotate testimonials
    setInterval(() => {
        navigateTestimonials(1);
    }, 5000);
}

// Navigate testimonials
function navigateTestimonials(direction) {
    const newIndex = (currentTestimonial + direction + testimonials.length) % testimonials.length;
    navigateToTestimonial(newIndex);
}

// Navigate to specific testimonial
function navigateToTestimonial(index) {
    currentTestimonial = index;
    
    // Update track position
    testimonialTrack.style.transform = `translateX(-${currentTestimonial * 100}%)`;
    
    // Update dots
    document.querySelectorAll('.slider-dot').forEach((dot, i) => {
        dot.classList.toggle('active', i === currentTestimonial);
    });
}

// Initialize rating stars
function initRatingStars() {
    // Reset stars on mouse leave
    document.querySelector('.rating-stars').addEventListener('mouseleave', resetStars);
}

// Handle star click
function handleStarClick(e) {
    const value = parseInt(e.target.closest('.star').getAttribute('data-value'));
    userRating = value;
    updateStars(userRating);
}

// Handle star hover
function handleStarHover(e) {
    const value = parseInt(e.target.closest('.star').getAttribute('data-value'));
    updateStars(value);
}

// Update stars display
function updateStars(value) {
    stars.forEach(star => {
        const starValue = parseInt(star.getAttribute('data-value'));
        if (starValue <= value) {
            star.innerHTML = '<i class="fas fa-star"></i>';
            star.classList.add('active');
        } else {
            star.innerHTML = '<i class="far fa-star"></i>';
            star.classList.remove('active');
        }
    });
}

// Reset stars to current rating
function resetStars() {
    updateStars(userRating);
}

// Handle comment form submission
function handleCommentSubmit(e) {
    e.preventDefault();
    
    if (userRating === 0) {
        alert('Please select a rating before submitting');
        return;
    }
    
    const comment = commentInput.value.trim();
    const name = document.getElementById('reviewerName')?.value || 'Anonymous';
    
    // Create review object with name and avatar
    const review = {
        id: Date.now(),
        name: name,
        avatar: `https://randomuser.me/api/portraits/lego/${Math.floor(Math.random() * 10) + 1}.jpg`,
        rating: userRating,
        comment: comment,
        date: new Date().toLocaleDateString('id-ID', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        })
    };
    
    // Add to reviews
    userReviews.push(review);
    
    // Save to localStorage
    localStorage.setItem('userReviews', JSON.stringify(userReviews));
    
    // Update testimonials
    loadUserReviews();
    
    // Show thank you message
    showSuccess('Thank you for your feedback!');
    
    // Reset form
    userRating = 0;
    resetStars();
    commentInput.value = '';
    if (document.getElementById('reviewerName')) {
        document.getElementById('reviewerName').value = '';
    }
}

// Handle contact form submission
function handleContactSubmit(e) {
    e.preventDefault();
    
    const name = document.getElementById('contactName').value;
    const email = document.getElementById('contactEmail').value;
    const message = document.getElementById('contactMessage').value;
    
    // In a real app, you would send this data to a server
    console.log('Contact form submitted:', { name, email, message });
    
    // Show success message
    showSuccess('Pesan Anda telah terkirim! Terima kasih telah menghubungi kami.');
    
    // Reset form
    contactForm.reset();
    
    // Close modal
    closeModal(contactModal);
}

// Load user reviews and display them in testimonials
function loadUserReviews() {
    const testimonialsContainer = document.getElementById('testimonialTrack');
    
    // Clear existing testimonials (except the default ones)
    if (userReviews.length > 0) {
        // Keep the first 3 default testimonials and add user reviews
        const defaultTestimonials = Array.from(testimonialsContainer.children).slice(0, 3);
        testimonialsContainer.innerHTML = '';
        defaultTestimonials.forEach(testimonial => testimonialsContainer.appendChild(testimonial));
        
        // Add user reviews
        userReviews.forEach(review => {
            const testimonialSlide = document.createElement('div');
            testimonialSlide.className = 'testimonial-slide';
            
            testimonialSlide.innerHTML = `
                <div class="testimonial-card">
                    <div class="testimonial-header">
                        <img src="${review.avatar || 'https://randomuser.me/api/portraits/lego/1.jpg'}" alt="User" class="testimonial-avatar">
                        <div class="testimonial-user">
                            <h4>${review.name || 'Anonymous'}</h4>
                            <div class="testimonial-rating">
                                ${getRatingStars(review.rating)}
                            </div>
                        </div>
                    </div>
                    <p class="testimonial-text">"${review.comment}"</p>
                    <div class="testimonial-date">${review.date}</div>
                </div>
            `;
            
            testimonialsContainer.appendChild(testimonialSlide);
        });
        
        // Reinitialize testimonials
        initTestimonials();
    }
    
    // Update stats in thanks modal
    const totalRating = userReviews.reduce((sum, review) => sum + review.rating, 0);
    const averageRating = userReviews.length > 0 ? (totalRating / userReviews.length).toFixed(1) : '4.9';
    
    document.getElementById('ratingValue').textContent = averageRating;
    document.getElementById('usersCount').textContent = `${userReviews.length + 500000}+`;
}

// Helper function to generate rating stars
function getRatingStars(rating) {
    let stars = '';
    for (let i = 1; i <= 5; i++) {
        if (i <= rating) {
            stars += '<i class="fas fa-star"></i>';
        } else if (i - 0.5 === rating) {
            stars += '<i class="fas fa-star-half-alt"></i>';
        } else {
            stars += '<i class="far fa-star"></i>';
        }
    }
    return stars;
}

// Show loading state
function showLoading() {
    spinner.style.display = 'block';
    downloadBtn.disabled = true;
}

// Hide loading state
function hideLoading() {
    spinner.style.display = 'none';
    downloadBtn.disabled = false;
}

// Show error message
function showError(message) {
    errorMessage.textContent = message;
    errorMessage.style.display = 'block';
    
    // Auto hide after 5 seconds
    setTimeout(() => {
        hideError();
    }, 5000);
}

// Hide error message
function hideError() {
    errorMessage.style.display = 'none';
}

// Show success message
function showSuccess(message) {
    successMessage.textContent = message;
    successMessage.style.display = 'block';
    
    // Auto hide after 5 seconds
    setTimeout(() => {
        hideSuccess();
    }, 5000);
}

// Hide success message
function hideSuccess() {
    successMessage.style.display = 'none';
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', init);